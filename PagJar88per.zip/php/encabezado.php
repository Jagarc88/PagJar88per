<?php 

return $result_encabezado = "<h1> YEY YEY YEY YEY </h1>"

?>