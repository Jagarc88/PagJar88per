<?php 

function writeMsg() {
    return "Hello world!";
}

?>