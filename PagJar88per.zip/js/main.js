
$(document).ready(function(){

   
   $(".titulo").on('mouseout', function() {
  		$( this ).css( "color", "black" );
	});
   $(".titulo").on('mouseover', function() {
  		$( this ).css( "color", "red" );
	});
});